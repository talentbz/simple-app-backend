/*
Template Name: Skote - Admin & Dashboard Template
Author: Themesbrand
Version: 3.0
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: ecommerce select2 Js File
*/

// Select2
$(".select2").select2();